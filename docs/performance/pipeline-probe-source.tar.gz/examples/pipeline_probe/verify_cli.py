"""Verify the release CLI without initializing GTK or opening any source."""
import itertools
import json
import os
from pathlib import Path
import subprocess
import sys


def verify(binary):
    environment = dict(os.environ)
    environment.pop("DISPLAY", None)
    environment.pop("WAYLAND_DISPLAY", None)
    valid = set()
    for mode, queue, rate in itertools.product(
        ("native", "software", "gl"), ("0", "1", "2"),
        (("--fps", "30"), ("--fps", "60"), ("--drop-fps", "30")),
    ):
        valid.add(("--mode", mode, "--queue", queue, *rate))
    for mode, io, fps in itertools.product(
        ("native", "software", "gl"),
        ("auto", "mmap", "dmabuf", "rw", "userptr", "dmabuf-import"), ("30", "60"),
    ):
        valid.add(("--device", "/dev/video999999", "--mode", mode, "--io-mode", io, "--fps", fps))
    for rgb, queue in itertools.product(("RGB", "BGRx", "BGRA"), ("0", "1", "2")):
        valid.add(("--mode", "software", "--rgb-format", rgb, "--queue", queue))
    for fps, queue in itertools.product(("30", "60"), ("0", "1", "2")):
        valid.add(("--device", "/dev/video999999", "--mode", "dmabuf", "--fps", fps, "--queue", queue))
    for state in ("paused", "ready", "null"):
        valid.add(("--pause-state", state, "--pause-after", "5", "--resume-after", "10"))
    invalid = [
        ("--device", "/dev/video2 ! fakesink"), ("--device", "/tmp/video2"),
        ("--device", "/dev/video"), ("--device", "/dev/video２"),
        ("--device", "/dev/video2/../video3"), ("--device",),
        ("--mode", "magic"), ("--fps", "59"), ("--fps", "+30"), ("--fps", "030"),
        ("--drop-fps", "60"), ("--queue", "3"),
        ("--mode", "software", "--rgb-format", "RGBA"), ("--rgb-format", "RGB"),
        ("--mode", "gl", "--rgb-format", "BGRA"), ("--io-mode", "mmap"),
        ("--io-mode", "auto"), ("--device", "/dev/video2", "--io-mode", "bogus"),
        ("--fps", "30", "--drop-fps", "30"), ("--mode", "native", "--mode", "gl"),
        ("--queue", "1", "--queue", "2"), ("--unknown", "value"),
        ("--pause-state", "ready"), ("--pause-after", "5"), ("--resume-after", "10"),
        ("--pause-state", "bogus", "--pause-after", "5"),
        ("--pause-state", "ready", "--pause-after", "0"),
        ("--pause-state", "ready", "--pause-after", "5", "--resume-after", "5"),
        ("--mode", "dmabuf"),
        ("--device", "/dev/video2", "--mode", "dmabuf", "--io-mode", "mmap"),
        ("--device", "/dev/video2", "--mode", "dmabuf", "--io-mode", "auto"),
        ("--device", "/dev/video2", "--mode", "dmabuf", "--drop-fps", "30"),
        ("--device", "/dev/video2", "--mode", "dmabuf", "--rgb-format", "RGB"),
        ("--print-pipeline",), ("--help", "--device", "/dev/video2"),
    ]
    records = []
    for expected, cases in ((0, sorted(valid)), (2, invalid)):
        for arguments in cases:
            command = [str(binary), "--print-pipeline", *arguments]
            result = subprocess.run(command, env=environment, text=True, capture_output=True, timeout=10)
            assert result.returncode == expected, (command, result.returncode, result.stdout, result.stderr)
            assert "BENCH_CONTEXT" not in result.stdout + result.stderr
            if expected == 0:
                assert result.stdout.rstrip().endswith("gtk4paintablesink name=display sync=false")
                assert not result.stderr, result.stderr
            records.append({"arguments": arguments, "exit_code": result.returncode,
                            "stdout": result.stdout, "stderr": result.stderr})
    help_result = subprocess.run([str(binary), "--help"], env=environment, text=True,
                                 capture_output=True, timeout=10, check=True)
    assert "dmabuf" in help_result.stdout and not help_result.stderr
    output = binary.parents[3] / "probe-cli-results.json"
    output.write_text(json.dumps(records, indent=2) + "\n")
    print(json.dumps({"binary": str(binary), "valid_graphs": len(valid),
                      "invalid_rejected": len(invalid), "help": "passed",
                      "display_environment": "unset", "results": str(output)}))


if __name__ == "__main__":
    verify(Path(sys.argv[1]).resolve(strict=True))
