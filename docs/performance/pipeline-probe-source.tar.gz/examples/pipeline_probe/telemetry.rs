fn frames_per_second(before: u64, after: u64, seconds: f64) -> f64 {
    after.saturating_sub(before) as f64 / seconds
}

use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};

struct Stats {
    frames: AtomicU64,
    sources: AtomicU64,
    resume_start_us: AtomicU64,
    first_source_pts: AtomicU64,
    resume_latency_us: AtomicU64,
}

impl Stats {
    fn new() -> Self {
        Self {
            frames: AtomicU64::new(0),
            sources: AtomicU64::new(0),
            resume_start_us: AtomicU64::new(0),
            first_source_pts: AtomicU64::new(u64::MAX),
            resume_latency_us: AtomicU64::new(u64::MAX),
        }
    }
    fn arm_resume(&self, now_us: u64) {
        self.first_source_pts.store(u64::MAX, Ordering::SeqCst);
        self.resume_latency_us.store(u64::MAX, Ordering::SeqCst);
        self.resume_start_us.store(now_us + 1, Ordering::SeqCst);
    }
    fn source_buffer(&self, pts: Option<u64>) {
        self.sources.fetch_add(1, Ordering::Relaxed);
        if self.resume_start_us.load(Ordering::SeqCst) != 0 {
            if let Some(pts) = pts {
                let _ = self.first_source_pts.compare_exchange(
                    u64::MAX,
                    pts,
                    Ordering::SeqCst,
                    Ordering::SeqCst,
                );
            }
        }
    }
    fn delivered_buffer(&self, pts: Option<u64>, now_us: u64) {
        self.frames.fetch_add(1, Ordering::Relaxed);
        let first = self.first_source_pts.load(Ordering::SeqCst);
        if first != u64::MAX && pts.is_some_and(|pts| pts >= first) {
            let start = self.resume_start_us.swap(0, Ordering::SeqCst);
            if start != 0 {
                self.resume_latency_us
                    .store(now_us.saturating_sub(start - 1), Ordering::SeqCst);
            }
        }
    }
    fn delivered_count(&self) -> u64 {
        self.frames.load(Ordering::Relaxed)
    }
    fn take_resume_latency_us(&self) -> Option<u64> {
        let latency = self.resume_latency_us.swap(u64::MAX, Ordering::SeqCst);
        (latency != u64::MAX).then_some(latency)
    }
}

use gstreamer::{self as gst, prelude::*};
use gtk4::glib;
use std::{
    cell::Cell,
    sync::Arc,
    time::{Duration, Instant},
};

pub struct Telemetry {
    stats: Arc<Stats>,
    clock: Instant,
    logger: Option<glib::SourceId>,
    probes: Vec<(gst::Pad, gst::PadProbeId)>,
}

impl Telemetry {
    pub fn arm_resume(&self) {
        self.stats
            .arm_resume(self.clock.elapsed().as_micros() as u64);
    }
}

impl Drop for Telemetry {
    fn drop(&mut self) {
        // The pipeline remains owned by Running until this logger is removed.
        if let Some(logger) = self.logger.take() {
            logger.remove();
        }
        for (pad, id) in self.probes.drain(..) {
            pad.remove_probe(id);
        }
    }
}

pub fn install(pipeline: &gst::Pipeline) -> Result<Telemetry, String> {
    let sink_pad = pipeline
        .by_name("display")
        .and_then(|sink| sink.static_pad("sink"))
        .ok_or("missing GTK sink pad")?;
    let source_pad = pipeline
        .by_name("source")
        .and_then(|source| source.static_pad("src"))
        .ok_or("missing source pad")?;
    let stats = Arc::new(Stats::new());
    let clock = Instant::now();
    let source_stats = stats.clone();
    let source_memory_logged = AtomicBool::new(false);
    let source_probe = source_pad
        .add_probe(gst::PadProbeType::BUFFER, move |_, info| {
            if !source_memory_logged.load(Ordering::Relaxed) {
                if let Some(buffer) = info.buffer() {
                    eprintln!(
                        "BENCH_MEMORY location=source types={}",
                        memory_types(buffer)
                    );
                    source_memory_logged.store(true, Ordering::Relaxed);
                }
            }
            let pts = info
                .buffer()
                .and_then(|buffer| buffer.pts())
                .map(|pts| pts.nseconds());
            source_stats.source_buffer(pts);
            gst::PadProbeReturn::Ok
        })
        .ok_or("cannot install source counter")?;
    let delivered_stats = stats.clone();
    let sink_memory_logged = AtomicBool::new(false);
    let sink_probe = sink_pad
        .add_probe(gst::PadProbeType::BUFFER, move |_, info| {
            if !sink_memory_logged.load(Ordering::Relaxed) {
                if let Some(buffer) = info.buffer() {
                    eprintln!(
                        "BENCH_MEMORY location=display types={}",
                        memory_types(buffer)
                    );
                    sink_memory_logged.store(true, Ordering::Relaxed);
                }
            }
            let pts = info
                .buffer()
                .and_then(|buffer| buffer.pts())
                .map(|pts| pts.nseconds());
            delivered_stats.delivered_buffer(pts, clock.elapsed().as_micros() as u64);
            gst::PadProbeReturn::Ok
        })
        .ok_or("cannot install sink counter")?;
    let (log_stats, log_sink, log_source) = (stats.clone(), sink_pad.clone(), source_pad.clone());
    let weak_pipeline = pipeline.downgrade();
    let (last_count, last_source, last_time) = (Cell::new(0), Cell::new(0), Cell::new(clock));
    let logger = glib::timeout_add_local(Duration::from_secs(3), move || {
        let Some(pipeline) = weak_pipeline.upgrade() else {
            return glib::ControlFlow::Break;
        };
        let now = Instant::now();
        let seconds = now.duration_since(last_time.replace(now)).as_secs_f64();
        let count = log_stats.delivered_count();
        let source = log_stats.sources.load(Ordering::Relaxed);
        let fps = frames_per_second(last_count.replace(count), count, seconds);
        let source_fps = frames_per_second(last_source.replace(source), source, seconds);
        let caps = log_sink
            .current_caps()
            .map(|caps| caps.to_string())
            .unwrap_or_default();
        let source_caps = log_source
            .current_caps()
            .map(|caps| caps.to_string())
            .unwrap_or_default();
        eprintln!("BENCH_FRAME frames={count} fps={fps:.3} caps={caps} source_frames={source} source_fps={source_fps:.3} source_caps={source_caps} state={:?}", pipeline.current_state());
        if let Some(latency) = log_stats.take_resume_latency_us() {
            eprintln!("BENCH_RESUME first_post_resume_source_delivered_us={latency}");
        }
        glib::ControlFlow::Continue
    });
    Ok(Telemetry {
        stats,
        clock,
        logger: Some(logger),
        probes: vec![(source_pad, source_probe), (sink_pad, sink_probe)],
    })
}

fn memory_types(buffer: &gst::BufferRef) -> String {
    buffer
        .iter_memories()
        .map(|memory| {
            memory
                .allocator()
                .map(|allocator| allocator.memory_type().to_string())
                .unwrap_or_else(|| "unknown".into())
        })
        .collect::<Vec<_>>()
        .join(",")
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn buffer_memory_report_inspects_allocator_without_cpu_mapping() {
        gst::init().unwrap();
        let buffer = gst::Buffer::with_size(16).unwrap();
        assert_eq!(memory_types(&buffer), "SystemMemory");
    }

    #[test]
    fn resume_timing_excludes_pre_resume_queued_buffers() {
        let stats = Stats::new();
        stats.delivered_buffer(Some(50), 50);
        assert_eq!(stats.delivered_count(), 1);
        stats.arm_resume(1000);
        stats.delivered_buffer(Some(99), 1020);
        assert_eq!(stats.take_resume_latency_us(), None);
        stats.source_buffer(Some(200));
        stats.delivered_buffer(Some(100), 1040);
        assert_eq!(stats.take_resume_latency_us(), None);
        // The first post-resume source buffer can be dropped upstream.
        stats.source_buffer(Some(300));
        stats.delivered_buffer(Some(300), 1100);
        assert_eq!(stats.take_resume_latency_us(), Some(100));
        assert_eq!(stats.take_resume_latency_us(), None);
        assert_eq!(stats.delivered_count(), 4);
        stats.arm_resume(2000);
        stats.source_buffer(None);
        stats.delivered_buffer(None, 2100);
        assert_eq!(stats.take_resume_latency_us(), None);
        stats.source_buffer(Some(0)); // PTS restarts following Null.
        stats.delivered_buffer(Some(0), 2200);
        assert_eq!(stats.take_resume_latency_us(), Some(200));
    }

    #[test]
    fn frame_rate_uses_delivered_buffers_not_caps() {
        assert_eq!(frames_per_second(100, 280, 3.0), 60.0);
        assert_eq!(frames_per_second(280, 280, 3.0), 0.0);
        assert_eq!(frames_per_second(280, 370, 3.0), 30.0);
    }
}
