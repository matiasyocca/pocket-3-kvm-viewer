use gstreamer::{self as gst, prelude::*};
use gtk4::{self as gtk, gio, glib, prelude::*};
use std::{
    cell::{Cell, RefCell},
    rc::Rc,
    time::Duration,
};

type PendingTimer = Rc<RefCell<Option<glib::SourceId>>>;
pub struct DiagnosticTimers(Vec<PendingTimer>);

impl DiagnosticTimers {
    #[cfg(test)]
    pub fn len(&self) -> usize {
        self.0.len()
    }
    fn cancel(&mut self) {
        for pending in self.0.drain(..) {
            if let Some(id) = pending.borrow_mut().take() {
                id.remove();
            }
        }
    }
}

impl Drop for DiagnosticTimers {
    fn drop(&mut self) {
        self.cancel();
    }
}

pub fn state_timers(
    app: &gtk::Application,
    pipeline: &gst::Pipeline,
    config: &super::Config,
    telemetry: &Rc<super::telemetry::Telemetry>,
    failed: &Rc<Cell<bool>>,
) -> DiagnosticTimers {
    let mut timers = DiagnosticTimers(Vec::new());
    let pause_state = match config.pause_state.as_deref() {
        Some("paused") => gst::State::Paused,
        Some("ready") => gst::State::Ready,
        _ => gst::State::Null,
    };
    for (seconds, state, resume) in [
        (config.pause_after, pause_state, false),
        (config.resume_after, gst::State::Playing, true),
    ] {
        let Some(seconds) = seconds else {
            continue;
        };
        let pending: PendingTimer = Rc::new(RefCell::new(None));
        let (callback_pending, weak_pipeline, weak_app, error_failed, telemetry) = (
            pending.clone(),
            pipeline.downgrade(),
            app.downgrade(),
            failed.clone(),
            telemetry.clone(),
        );
        let id = glib::timeout_add_local_once(Duration::from_secs(seconds), move || {
            callback_pending.borrow_mut().take();
            let Some(pipeline) = weak_pipeline.upgrade() else {
                return;
            };
            if resume {
                telemetry.arm_resume();
            }
            eprintln!("BENCH_STATE requested={state:?} after_seconds={seconds}");
            if let Err(error) = pipeline.set_state(state) {
                eprintln!("BENCH_ERROR state_change={error}");
                error_failed.set(true);
                let _ = pipeline.set_state(gst::State::Null);
                if let Some(app) = weak_app.upgrade() {
                    app.quit();
                }
            }
        });
        *pending.borrow_mut() = Some(id);
        timers.0.push(pending);
    }
    timers
}

struct Running {
    pipeline: gst::Pipeline,
    watch: Option<gst::bus::BusWatchGuard>,
    telemetry: Option<Rc<super::telemetry::Telemetry>>,
    timers: DiagnosticTimers,
}

impl Drop for Running {
    fn drop(&mut self) {
        self.timers.cancel();
        self.watch.take();
        if let Err(error) = self.pipeline.set_state(gst::State::Null) {
            eprintln!("BENCH_ERROR cleanup={error}");
        }
        self.telemetry.take();
    }
}

pub fn run(config: super::Config) -> Result<i32, String> {
    gst::init().map_err(|error| format!("GStreamer initialization failed: {error}"))?;
    gstgtk4::plugin_register_static()
        .map_err(|error| format!("sink registration failed: {error}"))?;
    let app = gtk::Application::builder()
        .application_id("io.github.pocket3.KvmViewer")
        .flags(gio::ApplicationFlags::NON_UNIQUE)
        .build();
    let active = Rc::new(RefCell::new(None::<Running>));
    let failed = Rc::new(Cell::new(false));
    let (activate_active, activate_failed) = (active.clone(), failed.clone());
    app.connect_activate(move |app| {
        if activate_active.borrow().is_some() {
            return;
        }
        match start(app, &config, &activate_failed) {
            Ok(running) => *activate_active.borrow_mut() = Some(running),
            Err(error) => {
                eprintln!("BENCH_ERROR {error}");
                activate_failed.set(true);
                app.quit();
            }
        }
    });
    app.connect_shutdown(move |_| {
        active.borrow_mut().take();
    });
    let status = app.run_with_args(&["pipeline_probe"]);
    Ok(if failed.get() { 1 } else { status.into() })
}

fn start(
    app: &gtk::Application,
    config: &super::Config,
    failed: &Rc<Cell<bool>>,
) -> Result<Running, String> {
    let (pipeline, paintable) = build_pipeline(config)?;
    let window = gtk::ApplicationWindow::builder()
        .application(app)
        .title("Pocket 3 KVM Pipeline Probe")
        .default_width(960)
        .default_height(540)
        .build();
    window.add_css_class("kvm-pipeline-probe");
    let style = gtk::CssProvider::new();
    #[cfg(feature = "probe-native-yuv")]
    style.load_from_string(".kvm-pipeline-probe { background-color: #000; }");
    #[cfg(not(feature = "probe-native-yuv"))]
    style.load_from_data(".kvm-pipeline-probe { background-color: #000; }");
    gtk::style_context_add_provider_for_display(
        &gtk::prelude::WidgetExt::display(&window),
        &style,
        gtk::STYLE_PROVIDER_PRIORITY_APPLICATION,
    );
    let picture = gtk::Picture::for_paintable(&paintable);
    picture.set_hexpand(true);
    picture.set_vexpand(true);
    picture.set_can_shrink(true);
    picture.set_content_fit(gtk::ContentFit::Contain);
    window.set_child(Some(&picture));
    let (weak_app, weak_pipeline, error_failed) =
        (app.downgrade(), pipeline.downgrade(), failed.clone());
    let watch = pipeline
        .bus()
        .ok_or("missing pipeline bus")?
        .add_watch_local(move |_, message| {
            match message.view() {
                gst::MessageView::Error(error) => {
                    eprintln!(
                        "BENCH_ERROR capture={} debug={:?}",
                        error.error(),
                        error.debug()
                    );
                    error_failed.set(true);
                    if let Some(pipeline) = weak_pipeline.upgrade() {
                        if let Err(error) = pipeline.set_state(gst::State::Null) {
                            eprintln!("BENCH_ERROR cleanup={error}");
                        }
                    }
                    if let Some(app) = weak_app.upgrade() {
                        app.quit();
                    }
                    return glib::ControlFlow::Break;
                }
                gst::MessageView::Warning(warning) => {
                    eprintln!(
                        "BENCH_WARNING capture={} debug={:?}",
                        warning.error(),
                        warning.debug()
                    );
                }
                gst::MessageView::Eos(..) => {
                    if let Some(pipeline) = weak_pipeline.upgrade() {
                        let _ = pipeline.set_state(gst::State::Null);
                    }
                    if let Some(app) = weak_app.upgrade() {
                        app.quit();
                    }
                    return glib::ControlFlow::Break;
                }
                _ => (),
            }
            glib::ControlFlow::Continue
        })
        .map_err(|error| format!("cannot watch pipeline: {error}"))?;
    let close_pipeline = pipeline.downgrade();
    window.connect_close_request(move |_| {
        if let Some(pipeline) = close_pipeline.upgrade() {
            let _ = pipeline.set_state(gst::State::Null);
        }
        glib::Propagation::Proceed
    });
    // Only the parent-run executable calls this path; tests never present or play.
    let telemetry = Rc::new(super::telemetry::install(&pipeline)?);
    window.present();
    if let Err(error) = pipeline.set_state(gst::State::Playing) {
        let _ = pipeline.set_state(gst::State::Null);
        return Err(format!("cannot start pipeline: {error}"));
    }
    let timers = state_timers(app, &pipeline, config, &telemetry, failed);
    Ok(Running {
        pipeline,
        watch: Some(watch),
        telemetry: Some(telemetry),
        timers,
    })
}

pub fn build_pipeline(
    config: &super::Config,
) -> Result<(gst::Pipeline, gtk::gdk::Paintable), String> {
    let pipeline = gst::parse::launch(&super::pipeline_description(config))
        .map_err(|error| format!("pipeline construction failed: {error}"))?
        .dynamic_cast::<gst::Pipeline>()
        .map_err(|_| "launch did not construct a pipeline".to_owned())?;
    let sink = pipeline.by_name("display").ok_or("missing GTK sink")?;
    let paintable = sink.property::<gtk::gdk::Paintable>("paintable");
    let context = paintable.property::<Option<gtk::gdk::GLContext>>("gl-context");
    println!(
        "BENCH_CONTEXT gl_present={} mode={}",
        context.is_some(),
        config.mode
    );
    if config.mode == "gl" && context.is_none() {
        pipeline
            .set_state(gst::State::Null)
            .map_err(|error| format!("cleanup failed: {error}"))?;
        return Err(
            "GL mode requires the GTK paintable's GL context; refusing CPU fallback".into(),
        );
    }
    Ok((pipeline, paintable))
}
