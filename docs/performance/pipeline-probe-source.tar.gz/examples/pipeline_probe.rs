//! Isolated pipeline comparison probe; synthetic unless --device is explicit.

#[path = "pipeline_probe/runtime.rs"]
mod runtime;
#[path = "pipeline_probe/telemetry.rs"]
mod telemetry;

#[derive(Debug, PartialEq, Eq)]
struct Config {
    device: Option<String>,
    mode: String,
    fps: u32,
    drop_fps: Option<u32>,
    queue: u32,
    io_mode: String,
    rgb_format: String,
    pause_state: Option<String>,
    pause_after: Option<u64>,
    resume_after: Option<u64>,
}

fn parse_args(args: &[String]) -> Result<Config, String> {
    let mut config = Config {
        device: None,
        mode: "native".into(),
        fps: 60,
        drop_fps: None,
        queue: 2,
        io_mode: "auto".into(),
        rgb_format: "RGB".into(),
        pause_state: None,
        pause_after: None,
        resume_after: None,
    };
    let mut seen = std::collections::HashSet::new();
    for pair in args.chunks(2) {
        let [flag, value] = pair else {
            return Err("every option needs a value".into());
        };
        if !seen.insert(flag.as_str()) {
            return Err(format!("duplicate option: {flag}"));
        }
        let allowed: &[&str] = match flag.as_str() {
            "--device" => {
                if !value.strip_prefix("/dev/video").is_some_and(|digits| {
                    !digits.is_empty() && digits.bytes().all(|byte| byte.is_ascii_digit())
                }) {
                    return Err("--device must be /dev/video followed by ASCII digits".into());
                }
                &[]
            }
            "--mode" => &["software", "native", "gl", "dmabuf"],
            "--fps" => &["30", "60"],
            "--drop-fps" => &["30"],
            "--queue" => &["0", "1", "2"],
            "--io-mode" => &["auto", "mmap", "dmabuf", "rw", "userptr", "dmabuf-import"],
            "--rgb-format" => &["RGB", "BGRx", "BGRA"],
            "--pause-state" => &["paused", "ready", "null"],
            "--pause-after" | "--resume-after" => {
                if value.is_empty() || !value.bytes().all(|byte| byte.is_ascii_digit()) {
                    return Err(format!("{flag} must be positive integer seconds"));
                }
                let seconds = value
                    .parse::<u64>()
                    .map_err(|_| format!("{flag} is too large"))?;
                if seconds == 0 || seconds > 86400 {
                    return Err(format!("{flag} must be between 1 and 86400 seconds"));
                }
                &[]
            }
            _ => return Err(format!("unknown option: {flag}")),
        };
        if !allowed.is_empty() && !allowed.contains(&value.as_str()) {
            return Err(format!("{flag} must be one of {}", allowed.join("|")));
        }
        match flag.as_str() {
            "--device" => config.device = Some(value.clone()),
            "--mode" => config.mode = value.clone(),
            "--fps" => config.fps = value.parse().map_err(|_| "invalid fps")?,
            "--drop-fps" => config.drop_fps = Some(value.parse().map_err(|_| "invalid drop fps")?),
            "--queue" => config.queue = value.parse().map_err(|_| "invalid queue")?,
            "--io-mode" => config.io_mode = value.clone(),
            "--rgb-format" => config.rgb_format = value.clone(),
            "--pause-state" => config.pause_state = Some(value.clone()),
            "--pause-after" => {
                config.pause_after = Some(value.parse().map_err(|_| "invalid pause seconds")?)
            }
            "--resume-after" => {
                config.resume_after = Some(value.parse().map_err(|_| "invalid resume seconds")?)
            }
            _ => unreachable!("option already validated"),
        }
    }
    if seen.contains("--rgb-format") && config.mode != "software" {
        return Err("--rgb-format requires --mode software".into());
    }
    if seen.contains("--io-mode") && config.device.is_none() {
        return Err("--io-mode requires an explicit --device".into());
    }
    if config.drop_fps.is_some() && config.fps != 60 {
        return Err("--drop-fps 30 requires --fps 60 (30fps source is already capped)".into());
    }
    if config.mode == "dmabuf" {
        if config.device.is_none() {
            return Err("direct DMABuf mode requires an explicit --device".into());
        }
        if seen.contains("--io-mode") && config.io_mode != "dmabuf" {
            return Err(
                "direct DMABuf mode requires --io-mode dmabuf (implied when omitted)".into(),
            );
        }
        if config.drop_fps.is_some() {
            return Err(
                "direct DMABuf mode excludes --drop-fps to preserve the direct importer path"
                    .into(),
            );
        }
        config.io_mode = "dmabuf".into();
    }
    if config.pause_state.is_some() != config.pause_after.is_some() {
        return Err("--pause-state and --pause-after must be supplied together".into());
    }
    if let Some(resume) = config.resume_after {
        if config.pause_after.is_none_or(|pause| pause >= resume) {
            return Err("--resume-after must exceed --pause-after (both relative to initial Playing request)".into());
        }
    }
    Ok(config)
}

fn pipeline_description(config: &Config) -> String {
    let source = match &config.device {
        Some(path) => format!(
            "v4l2src name=source device={path} io-mode={}",
            config.io_mode
        ),
        None => "videotestsrc name=source is-live=true".into(),
    };
    let source_format = if config.mode == "dmabuf" {
        "video/x-raw(memory:DMABuf),format=DMA_DRM,drm-format=YUYV"
    } else {
        "video/x-raw,format=YUY2"
    };
    let mut elements = vec![source, format!(
        "capsfilter name=source_caps caps={source_format},width=1920,height=1080,framerate={}/1", config.fps
    )];
    if config.queue > 0 {
        elements.push(format!("queue name=freshness max-size-buffers={} max-size-bytes=0 max-size-time=0 leaky=downstream", config.queue));
    }
    if let Some(fps) = config.drop_fps {
        elements.push("videorate drop-only=true".into());
        elements.push(format!("video/x-raw,format=YUY2,framerate={fps}/1"));
    }
    match config.mode.as_str() {
        "software" => {
            elements.push("videoconvert".into());
            elements.push(format!("video/x-raw,format={}", config.rgb_format));
        }
        "gl" => {
            elements.push("glupload".into());
            elements.push("glcolorconvert".into());
            elements.push("video/x-raw(memory:GLMemory),format=RGBA,texture-target=2D".into());
        }
        "native" | "dmabuf" => (),
        _ => unreachable!("mode already validated"),
    }
    elements.push("gtk4paintablesink name=display sync=false".into());
    elements.join(" ! ")
}

#[derive(Debug, PartialEq, Eq)]
enum Invocation {
    Help,
    Print(Config),
    Run(Config),
}

fn invocation(args: &[String]) -> Result<Invocation, String> {
    if args == ["--help"] {
        return Ok(Invocation::Help);
    }
    let print_count = args
        .iter()
        .filter(|arg| arg.as_str() == "--print-pipeline")
        .count();
    if print_count > 1 {
        return Err("duplicate option: --print-pipeline".into());
    }
    let remaining: Vec<String> = args
        .iter()
        .filter(|arg| arg.as_str() != "--print-pipeline")
        .cloned()
        .collect();
    let config = parse_args(&remaining)?;
    Ok(if print_count == 1 {
        Invocation::Print(config)
    } else {
        Invocation::Run(config)
    })
}

const HELP: &str = "Usage: pipeline_probe [--print-pipeline] [OPTIONS]\n\
  --device /dev/videoN         explicit capture; otherwise safe live synthetic source\n\
  --mode software|native|gl|dmabuf  default native; never fall back\n\
                               dmabuf requires --device, implies io-mode=dmabuf, no --drop-fps\n\
  --fps 30|60                 source caps, default 60 at 1920x1080 YUY2\n\
  --drop-fps 30               60fps source, drop before CPU/GL conversion\n\
  --queue 0|1|2               default 2; 0 bypasses, otherwise leaky downstream\n\
  --io-mode auto|mmap|dmabuf|rw|userptr|dmabuf-import  requires --device\n\
  --rgb-format RGB|BGRx|BGRA   software only; default RGB\n\
  --pause-state paused|ready|null --pause-after N [--resume-after N]\n\
                               seconds since initial Playing request, 1..86400; resume > pause\n\
  --print-pipeline            validate/print graph only, no GTK/GStreamer initialization\n\
  --help                     standalone, no initialization\n\
Telemetry: BENCH_FRAME every 3s on stderr includes delivered/source FPS and caps.\n\
BENCH_RESUME measures first delivered buffer with a post-resume source PTS, not display latency.";

fn main() {
    let status = match invocation(&std::env::args().skip(1).collect::<Vec<_>>()) {
        Ok(Invocation::Help) => {
            println!("{HELP}");
            0
        }
        Ok(Invocation::Print(config)) => {
            println!("{}", pipeline_description(&config));
            0
        }
        Ok(Invocation::Run(config)) => {
            println!("BENCH_PIPELINE {}", pipeline_description(&config));
            match runtime::run(config) {
                Ok(status) => status,
                Err(error) => {
                    eprintln!("BENCH_ERROR {error}");
                    1
                }
            }
        }
        Err(error) => {
            eprintln!("Argument error: {error}\n{HELP}");
            2
        }
    };
    std::process::exit(status);
}

#[cfg(test)]
mod tests {
    use super::*;

    fn args(values: &[&str]) -> Vec<String> {
        values.iter().map(|value| (*value).into()).collect()
    }

    #[test]
    fn direct_dmabuf_requests_drm_memory_without_download_or_fallback() {
        use std::str::FromStr;
        gstreamer::init().unwrap();
        let config = parse_args(&args(&["--device", "/dev/video23", "--mode", "dmabuf"])).unwrap();
        assert_eq!(config.io_mode, "dmabuf");
        let graph = pipeline_description(&config);
        assert_eq!(graph, "v4l2src name=source device=/dev/video23 io-mode=dmabuf ! capsfilter name=source_caps caps=video/x-raw(memory:DMABuf),format=DMA_DRM,drm-format=YUYV,width=1920,height=1080,framerate=60/1 ! queue name=freshness max-size-buffers=2 max-size-bytes=0 max-size-time=0 leaky=downstream ! gtk4paintablesink name=display sync=false");
        let caps = gstreamer::Caps::from_str("video/x-raw(memory:DMABuf),format=DMA_DRM,drm-format=YUYV,width=1920,height=1080,framerate=60/1").unwrap();
        assert!(caps.features(0).unwrap().contains("memory:DMABuf"));
        assert_eq!(
            caps.structure(0)
                .unwrap()
                .get::<&str>("drm-format")
                .unwrap(),
            "YUYV"
        );
        for values in [
            vec!["--mode", "dmabuf"],
            vec![
                "--device",
                "/dev/video2",
                "--mode",
                "dmabuf",
                "--io-mode",
                "mmap",
            ],
            vec![
                "--device",
                "/dev/video2",
                "--mode",
                "dmabuf",
                "--io-mode",
                "auto",
            ],
            vec![
                "--device",
                "/dev/video2",
                "--mode",
                "dmabuf",
                "--drop-fps",
                "30",
            ],
            vec![
                "--device",
                "/dev/video2",
                "--mode",
                "dmabuf",
                "--rgb-format",
                "RGB",
            ],
        ] {
            assert!(parse_args(&args(&values)).is_err(), "accepted {values:?}");
        }
    }

    #[test]
    fn dry_run_and_help_are_explicit_non_graphical_actions() {
        assert_eq!(invocation(&args(&["--help"])).unwrap(), Invocation::Help);
        assert!(
            matches!(invocation(&args(&["--print-pipeline", "--mode", "gl"])).unwrap(), Invocation::Print(Config { mode, .. }) if mode == "gl")
        );
        assert!(matches!(
            invocation(&args(&[])).unwrap(),
            Invocation::Run(_)
        ));
        assert!(invocation(&args(&["--help", "--device", "/dev/video2"])).is_err());
        assert!(invocation(&args(&["--print-pipeline", "--print-pipeline"])).is_err());
        assert!(invocation(&args(&[
            "--print-pipeline",
            "--device",
            "/dev/video2 ! fakesink"
        ]))
        .is_err());
    }

    #[test]
    fn ui_entrypoint_is_available_without_launching_it() {
        let _entrypoint: fn(Config) -> Result<i32, String> = runtime::run;
    }

    #[test]
    #[ignore = "requires GTK display; initializes only, never presents or plays"]
    fn gtk_pipeline_graphs_and_caps_construct_in_null_without_opening_sources() {
        use gstreamer::{self as gst, prelude::*};
        use std::str::FromStr;
        gst::init().unwrap();
        gtk4::init().unwrap();
        gstgtk4::plugin_register_static().unwrap();
        for mode in ["native", "software", "gl"] {
            let config = parse_args(&args(&["--mode", mode])).unwrap();
            let (pipeline, paintable) = runtime::build_pipeline(&config).unwrap();
            assert_eq!(pipeline.current_state(), gst::State::Null);
            assert_eq!(
                pipeline.by_name("source").unwrap().current_state(),
                gst::State::Null
            );
            let pad = pipeline
                .by_name("display")
                .unwrap()
                .static_pad("sink")
                .unwrap();
            let caps = pad.query_caps(None);
            let wanted = gst::Caps::from_str(match mode {
                "native" => "video/x-raw,format=YUY2,width=1920,height=1080,framerate=60/1",
                "software" => "video/x-raw,format=RGB,width=1920,height=1080,framerate=60/1",
                _ => "video/x-raw(memory:GLMemory),format=RGBA,texture-target=2D,width=1920,height=1080,framerate=60/1",
            }).unwrap();
            assert!(caps.can_intersect(&wanted), "mode={mode} offered={caps}");
            let context = paintable.property::<Option<gtk4::gdk::GLContext>>("gl-context");
            if mode == "gl" {
                assert!(context.is_some());
            }
            let telemetry = telemetry::install(&pipeline).unwrap();
            telemetry.arm_resume();
            assert!(
                pad.current_caps().is_none(),
                "no actual negotiation or capture permitted"
            );
            drop(telemetry);
            let schedule = parse_args(&args(&[
                "--pause-state",
                "ready",
                "--pause-after",
                "5",
                "--resume-after",
                "10",
            ]))
            .unwrap();
            let app = gtk4::Application::builder()
                .application_id("io.github.pocket3.KvmViewer")
                .build();
            let telemetry = std::rc::Rc::new(telemetry::install(&pipeline).unwrap());
            let timers = runtime::state_timers(
                &app,
                &pipeline,
                &schedule,
                &telemetry,
                &std::rc::Rc::new(std::cell::Cell::new(false)),
            );
            assert_eq!(timers.len(), 2);
            drop(timers);
            drop(telemetry);
            pipeline.set_state(gst::State::Null).unwrap();
        }
        // Exercise conversion/drop/queue alternatives without crossing Null.
        for mode in ["native", "software", "gl"] {
            for queue in ["0", "1", "2"] {
                for rate in [
                    vec!["--fps", "30"],
                    vec!["--fps", "60"],
                    vec!["--drop-fps", "30"],
                ] {
                    let mut values = vec!["--mode", mode, "--queue", queue];
                    values.extend(rate);
                    let config = parse_args(&args(&values)).unwrap();
                    let (pipeline, _) = runtime::build_pipeline(&config).unwrap();
                    assert_eq!(pipeline.current_state(), gst::State::Null);
                    assert!(pipeline
                        .by_name("display")
                        .unwrap()
                        .static_pad("sink")
                        .unwrap()
                        .current_caps()
                        .is_none());
                }
            }
        }
        for rgb in ["RGB", "BGRx", "BGRA"] {
            let config = parse_args(&args(&["--mode", "software", "--rgb-format", rgb])).unwrap();
            let (pipeline, _) = runtime::build_pipeline(&config).unwrap();
            assert_eq!(pipeline.current_state(), gst::State::Null);
        }
        for io in ["auto", "mmap", "dmabuf", "rw", "userptr", "dmabuf-import"] {
            let config =
                parse_args(&args(&["--device", "/dev/video999999", "--io-mode", io])).unwrap();
            let (pipeline, _) = runtime::build_pipeline(&config).unwrap();
            assert_eq!(pipeline.current_state(), gst::State::Null);
            assert_eq!(
                pipeline.by_name("source").unwrap().current_state(),
                gst::State::Null
            );
        }
        #[cfg(feature = "probe-dmabuf")]
        {
            // Construction in Null cannot open even a numeric V4L2 path.
            let config =
                parse_args(&args(&["--device", "/dev/video999999", "--mode", "dmabuf"])).unwrap();
            match runtime::build_pipeline(&config) {
                Ok((pipeline, _)) => {
                    assert_eq!(pipeline.current_state(), gst::State::Null);
                    assert_eq!(
                        pipeline.by_name("source").unwrap().current_state(),
                        gst::State::Null
                    );
                    let pad = pipeline
                        .by_name("display")
                        .unwrap()
                        .static_pad("sink")
                        .unwrap();
                    assert!(pad.current_caps().is_none());
                    println!("BENCH_NULL_DMABUF graph_constructed=true");
                    pipeline.set_state(gst::State::Null).unwrap();
                }
                Err(error) => {
                    assert!(
                        error.starts_with("pipeline construction failed:"),
                        "unexpected failure: {error}"
                    );
                    println!("BENCH_NULL_DMABUF unsupported={error}");
                }
            }
        }
    }

    #[test]
    fn pause_options_require_an_ordered_schedule() {
        let config = parse_args(&args(&[
            "--pause-state",
            "ready",
            "--pause-after",
            "5",
            "--resume-after",
            "10",
        ]))
        .unwrap();
        assert_eq!(config.pause_state.as_deref(), Some("ready"));
        assert_eq!(config.pause_after, Some(5));
        assert_eq!(config.resume_after, Some(10));
        for state in ["paused", "ready", "null"] {
            assert!(parse_args(&args(&["--pause-state", state, "--pause-after", "5"])).is_ok());
        }
        for values in [
            vec!["--pause-state", "ready"],
            vec!["--pause-after", "5"],
            vec!["--resume-after", "10"],
            vec!["--pause-state", "bogus", "--pause-after", "5"],
            vec!["--pause-state", "ready", "--pause-after", "0"],
            vec!["--pause-state", "ready", "--pause-after", "-5"],
            vec![
                "--pause-state",
                "ready",
                "--pause-after",
                "5",
                "--resume-after",
                "5",
            ],
            vec![
                "--pause-state",
                "ready",
                "--pause-after",
                "10",
                "--resume-after",
                "5",
            ],
        ] {
            assert!(parse_args(&args(&values)).is_err(), "accepted {values:?}");
        }
    }

    #[test]
    fn frame_dropping_precedes_any_cpu_or_gl_conversion() {
        for mode in ["native", "software", "gl"] {
            let config = parse_args(&args(&["--mode", mode, "--drop-fps", "30"])).unwrap();
            let graph = pipeline_description(&config);
            let drop = graph
                .find("videorate drop-only=true ! video/x-raw,format=YUY2,framerate=30/1")
                .expect("upstream drop filter");
            assert!(graph.contains("name=source_caps caps=video/x-raw,format=YUY2,width=1920,height=1080,framerate=60/1"));
            for conversion in ["videoconvert", "glupload", "gtk4paintablesink"] {
                if let Some(position) = graph.find(conversion) {
                    assert!(drop < position);
                }
            }
        }
    }

    #[test]
    fn conversion_mode_has_explicit_output_memory_and_format() {
        for rgb in ["RGB", "BGRx", "BGRA"] {
            let config = parse_args(&args(&["--mode", "software", "--rgb-format", rgb])).unwrap();
            let graph = pipeline_description(&config);
            assert!(
                graph.contains(&format!(
                    "videoconvert ! video/x-raw,format={rgb} ! gtk4paintablesink"
                )),
                "{graph}"
            );
            assert!(!graph.contains("glupload"));
        }
        let config = parse_args(&args(&["--mode", "gl"])).unwrap();
        let graph = pipeline_description(&config);
        assert!(graph.contains("glupload ! glcolorconvert ! video/x-raw(memory:GLMemory),format=RGBA,texture-target=2D ! gtk4paintablesink"), "{graph}");
        assert!(!graph.contains("gldownload"));
        assert!(!graph.contains("videoconvert"));
    }

    #[test]
    fn native_graph_preserves_yuy2_source_caps_and_freshness_queue() {
        let config = parse_args(&args(&[])).unwrap();
        assert_eq!(pipeline_description(&config),
            "videotestsrc name=source is-live=true ! capsfilter name=source_caps caps=video/x-raw,format=YUY2,width=1920,height=1080,framerate=60/1 ! queue name=freshness max-size-buffers=2 max-size-bytes=0 max-size-time=0 leaky=downstream ! gtk4paintablesink name=display sync=false");
        let config = parse_args(&args(&[
            "--device",
            "/dev/video23",
            "--io-mode",
            "dmabuf",
            "--fps",
            "30",
            "--queue",
            "0",
        ]))
        .unwrap();
        let graph = pipeline_description(&config);
        assert!(graph.starts_with("v4l2src name=source device=/dev/video23 io-mode=dmabuf ! "));
        assert!(graph.contains("framerate=30/1"));
        assert!(!graph.contains("queue"));
        assert!(!graph.contains("videoconvert"));
    }

    #[test]
    fn rejects_invalid_or_conflicting_arguments_before_initialization() {
        for values in [
            vec!["--device", "/dev/video2 ! fakesink"],
            vec!["--device", "/tmp/video2"],
            vec!["--device", "/dev/video"],
            vec!["--device", "/dev/video２"],
            vec!["--device", "/dev/video2/../video3"],
            vec!["--mode", "magic"],
            vec!["--fps", "59"],
            vec!["--fps", "+30"],
            vec!["--fps", "030"],
            vec!["--drop-fps", "60"],
            vec!["--queue", "3"],
            vec!["--mode", "software", "--rgb-format", "RGBA"],
            vec!["--rgb-format", "RGB"],
            vec!["--mode", "gl", "--rgb-format", "BGRA"],
            vec!["--io-mode", "mmap"],
            vec!["--io-mode", "auto"],
            vec!["--device", "/dev/video2", "--io-mode", "bogus"],
            vec!["--fps", "30", "--drop-fps", "30"],
            vec!["--mode", "native", "--mode", "gl"],
            vec!["--queue", "1", "--queue", "2"],
            vec!["--device"],
            vec!["--unknown", "value"],
        ] {
            assert!(parse_args(&args(&values)).is_err(), "accepted {values:?}");
        }
        for io in ["auto", "mmap", "dmabuf", "rw", "userptr", "dmabuf-import"] {
            assert!(parse_args(&args(&["--device", "/dev/video2", "--io-mode", io])).is_ok());
        }
        for mode in ["software", "native", "gl"] {
            assert!(parse_args(&args(&["--mode", mode, "--fps", "30", "--queue", "0"])).is_ok());
        }
        for rgb in ["RGB", "BGRx", "BGRA"] {
            assert!(parse_args(&args(&["--mode", "software", "--rgb-format", rgb])).is_ok());
        }
    }

    #[test]
    fn accepts_explicit_hardware_software_comparison() {
        let config = parse_args(&args(&[
            "--device",
            "/dev/video23",
            "--mode",
            "software",
            "--fps",
            "60",
            "--drop-fps",
            "30",
            "--queue",
            "1",
            "--io-mode",
            "mmap",
            "--rgb-format",
            "BGRx",
        ]))
        .unwrap();
        assert_eq!(config.device.as_deref(), Some("/dev/video23"));
        assert_eq!(config.mode, "software");
        assert_eq!(config.fps, 60);
        assert_eq!(config.drop_fps, Some(30));
        assert_eq!(config.queue, 1);
        assert_eq!(config.io_mode, "mmap");
        assert_eq!(config.rgb_format, "BGRx");
    }

    #[test]
    fn default_is_safe_synthetic_native_1080p60() {
        let config = parse_args(&args(&[])).unwrap();
        assert_eq!(config.device, None);
        assert_eq!(config.mode, "native");
        assert_eq!(config.fps, 60);
        assert_eq!(config.drop_fps, None);
        assert_eq!(config.queue, 2);
        assert_eq!(config.io_mode, "auto");
        assert_eq!(config.rgb_format, "RGB");
    }
}
