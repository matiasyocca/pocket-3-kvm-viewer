# Isolated GTK/GStreamer pipeline probe

This detached worktree starts at `e399aba`. It does not modify the parent's source or target directory. No commits were made. Build and benchmark operations share `${HOME}/.hermes/cache/scratch/kvm-exclusive-bench.lock`.

## Build / verify

From this worktree:

```sh
flock ${HOME}/.hermes/cache/scratch/kvm-exclusive-bench.lock nix develop -c cargo build --locked --release --example pipeline_probe --all-features
flock ${HOME}/.hermes/cache/scratch/kvm-exclusive-bench.lock nix develop -c cargo fmt --all -- --check
flock ${HOME}/.hermes/cache/scratch/kvm-exclusive-bench.lock nix develop -c cargo test --locked --all-targets --all-features
flock ${HOME}/.hermes/cache/scratch/kvm-exclusive-bench.lock nix develop -c cargo clippy --locked --all-targets --all-features -- -D warnings
flock ${HOME}/.hermes/cache/scratch/kvm-exclusive-bench.lock nix develop -c cargo test --locked --example pipeline_probe --all-features gtk_pipeline_graphs_and_caps_construct_in_null_without_opening_sources -- --ignored --nocapture --test-threads=1
flock ${HOME}/.hermes/cache/scratch/kvm-exclusive-bench.lock nix develop -c python3 examples/pipeline_probe/verify_cli.py ./target/release/examples/pipeline_probe
```

The explicitly selected GTK test initializes the display and GPU context but never presents a window or sets any source above Null. Even its V4L2 objects stay Null, so no capture nodes are opened. Do not run all ignored baseline tests: they include interactive/hardware tests outside this probe's scope.

Optional features:
- `probe-gl`: gtk4paintablesink Wayland EGL, X11 EGL, X11 GLX support.
- `probe-native-yuv`: GTK/sink 4.20 API feature for direct YUY2 textures.
- `probe-dmabuf`: sink DMABuf importer plus `probe-native-yuv`.

The Nix shell supplies GTK 4.22.4 and GStreamer 1.28.4. `libglvnd` was added because the GL EGL pkg-config dependency needs `egl.pc`. Existing lockfile package versions are unchanged; only optional platform/allocator dependencies were added. The worktree's baseline `src/ui.rs` has a feature-gated equivalent CSS loader to avoid the GTK 4.12 deprecation when building all targets with modern GTK features.

## Executable / CLI

```sh
BIN=${HOME}/.hermes/cache/scratch/kvm-pipeline-probes-1791910988-277141/target/release/examples/pipeline_probe
"$BIN" --help
"$BIN" --print-pipeline --mode gl
"$BIN" --print-pipeline --device /dev/video2 --mode dmabuf
```

Help and `--print-pipeline` exit before GTK/GStreamer initialization. They were exercised with DISPLAY and WAYLAND_DISPLAY unset. The verifier checks 81 accepted graph configurations, 35 rejected argument configurations, and help.

The actual GUI/capture commands below are **for the parent to run**, not part of this subagent's execution. Run with the Nix development environment available and the exclusive benchmark lock. Substitute a confirmed numeric device path if the capture device is not `/dev/video2`.

```sh
"$BIN" --device /dev/video2 --mode software --rgb-format RGB
"$BIN" --device /dev/video2 --mode software --rgb-format BGRx
"$BIN" --device /dev/video2 --mode software --rgb-format BGRA
"$BIN" --device /dev/video2 --mode native
"$BIN" --device /dev/video2 --mode gl
"$BIN" --device /dev/video2 --mode dmabuf
"$BIN" --device /dev/video2 --mode native --fps 30
"$BIN" --device /dev/video2 --mode native --fps 60 --drop-fps 30
"$BIN" --device /dev/video2 --mode native --queue 0
"$BIN" --device /dev/video2 --mode native --queue 1
"$BIN" --device /dev/video2 --mode native --queue 2
"$BIN" --device /dev/video2 --mode native --io-mode auto
"$BIN" --device /dev/video2 --mode native --io-mode mmap
"$BIN" --device /dev/video2 --mode native --io-mode dmabuf
"$BIN" --device /dev/video2 --mode native --io-mode rw
"$BIN" --device /dev/video2 --mode native --io-mode userptr
"$BIN" --device /dev/video2 --mode native --io-mode dmabuf-import
"$BIN" --device /dev/video2 --mode native --pause-state paused --pause-after 5 --resume-after 15
"$BIN" --device /dev/video2 --mode native --pause-state ready --pause-after 5 --resume-after 15
"$BIN" --device /dev/video2 --mode native --pause-state null --pause-after 5 --resume-after 15
```

Defaults: safe synthetic `videotestsrc is-live=true`, native mode, YUY2 1920x1080 60/1 source caps, queue 2, IO auto, software RGB. There is no device discovery or automatic capture. All explicit device paths require `/dev/video` followed by ASCII digits; values, unknown flags, duplicate flags and conflicts are rejected before initialization.

- `--mode software`: `videoconvert` followed by explicit system-memory RGB/BGRx/BGRA caps.
- `--mode native`: YUY2 directly to GTK, no converter.
- `--mode gl`: `glupload ! glcolorconvert ! video/x-raw(memory:GLMemory),format=RGBA,texture-target=2D`; no CPU download. The paintable's `Option<gdk::GLContext>` must be present; absence is a fatal comparison result, not a CPU fallback.
- `--mode dmabuf`: requires explicit device, implies `io-mode=dmabuf`, and forces `video/x-raw(memory:DMABuf),format=DMA_DRM,drm-format=YUYV,width=1920,height=1080,framerate=60/1` (or 30/1 with `--fps 30`) directly to GTK. No videoconvert/glupload/download. `--drop-fps` is rejected in this mode to retain the direct importer path. Explicit IO mode must be dmabuf. Null graph construction succeeded here; **real V4L2 export/negotiation/import is not verified**.
- `--fps 30|60` changes source caps, never just negotiated sink metadata.
- `--drop-fps 30` requires a 60fps source and puts `videorate drop-only=true` plus 30/1 YUY2 caps upstream of conversion.
- `--queue 0|1|2`: bypass or downstream-leaky queue, buffer-limited with byte/time limits explicitly disabled.
- `--io-mode` requires explicit device; `--rgb-format` requires software mode.
- Pause state and pause-after must appear together. Positive integer seconds range 1..86400. Resume-after is optional and must exceed pause-after; both are relative to the initial Playing request, not a duration after pause.

## Parent benchmark integration

Example (parent execution only):

```sh
flock ${HOME}/.hermes/cache/scratch/kvm-exclusive-bench.lock \
  nix develop ${HOME}/.hermes/cache/scratch/kvm-pipeline-probes-1791910988-277141 -c \
  python3 ${HOME}/Developer/foundry/gpd-kvm/scripts/benchmark.py "$BIN" \
  --label probe-native --revision e399aba-isolated-probe \
  --output ${HOME}/Developer/foundry/gpd-kvm/docs/performance/probe-results.jsonl \
  --argument=--device --argument=/dev/video2 --argument=--mode --argument=native
```

Use `--allow-no-capture` and omit device/IO arguments when deliberately benchmarking synthetic source. Hold the lock at the outer benchmark invocation; the binary itself does not lock, so it cannot deadlock against the benchmark owner.

## Diagnostics / boundaries

App ID `io.github.pocket3.KvmViewer`, initial 960x540 window, black background, `gtk::Picture` Contain. No automatic visibility pause or production controls affect measurements.

- stdout: validated `BENCH_PIPELINE` and `BENCH_CONTEXT gl_present=...`; no environment or credentials are logged.
- stderr every three seconds: `BENCH_FRAME frames=... fps=... caps=... source_frames=... source_fps=... source_caps=... state=...` using actual Arc/Atomic counters at source and GTK sink pads. FPS is delivered-buffer throughput, **not displayed FPS**.
- `BENCH_MEMORY location=source|display types=...` inspects first buffer allocator types without mapping pixels. Pair these with negotiated memory/DRM caps to distinguish native system-memory YUY2 using dmabuf IO from a real direct DMABuf importer path.
- Bus warnings and errors include debug information. Capture ERROR requests Null before quitting with failure; close/EOS/shutdown also request Null. Failed graph construction, export, negotiation, or importer support is evidence of rejection, not grounds for silent fallback.
- `BENCH_STATE` records timer state requests. `BENCH_RESUME first_post_resume_source_delivered_us=...` measures first sink delivery whose PTS is at least the first source-pad buffer after the resume request. It excludes earlier queued PTS and handles dropped first frames/restarted PTS, but is **not sensor acquisition freshness or visible presentation latency**.

Actual capture, GUI presentation, compositor actions, screenshots and hardware benchmarks were deliberately not run. The parent must determine before/after benefit and drop no-benefit alternatives.
